from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_POST
from django.shortcuts import render,redirect
from django.contrib import messages
from django.core.serializers import serialize
import json
from .models import Mascota,Solicitud
# Create your views here.
def index(request):

    mascota = Mascota.objects.filter(estado='disponible')
    contexto = {
        'mascota': mascota,
    }

    return render(request, 'index.html', contexto)

from django.shortcuts import render
from .models import Mascota

def lista_mascotas(request):
    mascotas_adoptadas = Mascota.objects.filter(estado='adoptado')
    return render(request, 'index.html', {'aplicaciones': mascotas_adoptadas})

def nuevaMascota(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        especie = request.POST['especie']
        edad = request.POST['edad']
        estado = request.POST.get('estado', 'disponible')
        icono = request.FILES.get('icono')
        nueva_mascota = Mascota(nombre=nombre, especie=especie, edad=edad, estado=estado, icono=icono)
        nueva_mascota.save()
        messages.success(request, 'Mascota agregada exitosamente.')
        return redirect('index')
    return render(request, 'nuevaMascota.html')

def nuevaSolicitud(request):
    if request.method == 'POST':
        nombre_solicitante = request.POST['nombre_solicitante']
        email = request.POST['email']
        telefono = request.POST['telefono']
        mascota_id = request.POST['mascota']
        mascota = Mascota.objects.get(codigo=mascota_id)
        

        if mascota.estado != 'disponible':
            messages.error(request, 'Esta mascota ya no está disponible para adopción.')
            return redirect('nueva_solicitud')
        
        nueva_solicitud = Solicitud(nombre_solicitante=nombre_solicitante, email=email, telefono=telefono, mascota=mascota)
        nueva_solicitud.save()
        
        messages.success(request, 'Solicitud de adopción enviada exitosamente. La mascota ya no estará disponible para otras adopciones.')
        return redirect('lista_solicitudes')
    mascotas = Mascota.objects.filter(estado='disponible')
    return render(request, 'nuevaSolicitud.html', {'mascotas': mascotas})

def editarMascota(request, mascota_id):
    mascota = Mascota.objects.get(codigo=mascota_id)
    if request.method == 'POST':
        mascota.nombre = request.POST['nombre']
        mascota.especie = request.POST['especie']
        mascota.edad = request.POST['edad']
        mascota.estado = request.POST['estado']
        if 'icono' in request.FILES:
            mascota.icono = request.FILES['icono']
        mascota.save()
        messages.success(request, 'Mascota actualizada exitosamente.')
        return redirect('index')
    return render(request, 'editarMascota.html', {'mascota': mascota})

@require_POST
def eliminarMascota(request, mascota_id):
    mascota = Mascota.objects.get(codigo=mascota_id)
    mascota.delete()
    messages.success(request, 'Mascota eliminada exitosamente.')
    return redirect('index')

def editarSolicitud(request, solicitud_id):
    solicitud = Solicitud.objects.get(codigo=solicitud_id)
    if request.method == 'POST':
        solicitud.nombre_solicitante = request.POST['nombre_solicitante']
        solicitud.email = request.POST['email']
        solicitud.telefono = request.POST['telefono']
        nueva_mascota_id = request.POST['mascota']
        nueva_mascota = Mascota.objects.get(codigo=nueva_mascota_id)
        if nueva_mascota.estado == 'adoptado' and nueva_mascota != solicitud.mascota:
            messages.error(request, 'La mascota seleccionada ya está adoptada.')
            mascotas = Mascota.objects.filter(estado='disponible') | Mascota.objects.filter(codigo=solicitud.mascota.codigo)
            return render(request, 'editarSolicitud.html', {'solicitud': solicitud, 'mascotas': mascotas})

        if solicitud.mascota != nueva_mascota:
            solicitud.mascota.estado = 'disponible'
            solicitud.mascota.save()

            nueva_mascota.estado = 'adoptado'
            nueva_mascota.save()
        solicitud.mascota = nueva_mascota
        solicitud.save()
        messages.success(request, 'Solicitud actualizada exitosamente.')
        return redirect('lista_solicitudes')
    mascotas = Mascota.objects.filter(estado='disponible') | Mascota.objects.filter(codigo=solicitud.mascota.codigo)
    return render(request, 'editarSolicitud.html', {'solicitud': solicitud, 'mascotas': mascotas})

@require_POST
def eliminarSolicitud(request, solicitud_id):
    solicitud = Solicitud.objects.get(codigo=solicitud_id)
    mascota = solicitud.mascota
    solicitud.delete()

    mascota.estado = 'disponible'
    mascota.save()
    messages.success(request, 'Solicitud eliminada exitosamente.')
    return redirect('lista_solicitudes')

def lista_solicitudes(request):
    solicitudes = Solicitud.objects.all().select_related('mascota')
    return render(request, 'listaSolicitudes.html', {'solicitudes': solicitudes})

@require_POST
def aprobarSolicitud(request, solicitud_id):
    solicitud = Solicitud.objects.get(codigo=solicitud_id)
    if solicitud.estado == 'pendiente':
        solicitud.estado = 'aprobada'
        solicitud.save()

        solicitud.mascota.estado = 'adoptado'
        solicitud.mascota.save()

        Solicitud.objects.filter(mascota=solicitud.mascota, estado='pendiente').exclude(codigo=solicitud_id).update(estado='rechazada')
        messages.success(request, 'Solicitud aprobada exitosamente. Las demás solicitudes para esta mascota han sido rechazadas.')
    else:
        messages.error(request, 'La solicitud ya ha sido procesada.')
    return redirect('lista_solicitudes')

@require_POST
def rechazarSolicitud(request, solicitud_id):
    solicitud = Solicitud.objects.get(codigo=solicitud_id)
    if solicitud.estado == 'pendiente':
        solicitud.estado = 'rechazada'
        solicitud.save()
        # Cambiar el estado de la mascota de vuelta a disponible

        messages.success(request, 'Solicitud rechazada exitosamente.')
    else:
        messages.error(request, 'La solicitud ya ha sido procesada.')
    return redirect('lista_solicitudes')
