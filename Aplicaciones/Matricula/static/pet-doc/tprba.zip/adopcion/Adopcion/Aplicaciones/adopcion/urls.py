from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('mascotas/', views.lista_mascotas, name='lista_mascotas'),
    path('solicitudes/', views.lista_solicitudes, name='lista_solicitudes'),
    path('nuevaMascota/', views.nuevaMascota, name='nueva_mascota'),
    path('editarMascota/<int:mascota_id>/', views.editarMascota, name='editar_mascota'),
    path('eliminarMascota/<int:mascota_id>/', views.eliminarMascota, name='eliminar_mascota'),
    path('nuevaSolicitud/', views.nuevaSolicitud, name='nueva_solicitud'),
    path('editarSolicitud/<int:solicitud_id>/', views.editarSolicitud, name='editar_solicitud'),
    path('eliminarSolicitud/<int:solicitud_id>/', views.eliminarSolicitud, name='eliminar_solicitud'),
    path('aprobarSolicitud/<int:solicitud_id>/', views.aprobarSolicitud, name='aprobar_solicitud'),
    path('rechazarSolicitud/<int:solicitud_id>/', views.rechazarSolicitud, name='rechazar_solicitud'),
]