from django.urls import path
from . import views
urlpatterns=[
    path('',views.index),#Listado de Productos
    path('nuevaAplicacion',views.nuevaAplicacion),
    path('guardarAplicacion',views.guardarAplicacion),
    path('eliminarAplicacion/<id>',views.eliminarAplicacion),
    path('editarAplicacion/<id>',views.editarAplicacion),
    path('procesarActualizacionAplicacion',views.procesarActualizacionAplicacion),

    path('vistaCategorias',views.vistaCategorias),#Listado de Productos
    path('nuevaCategoria',views.nuevaCategoria),
    path('guardarCategoria',views.guardarCategoria),
    path('eliminarCategoria/<id>',views.eliminarCategoria),
    path('editarCategoria/<id>',views.editarCategoria),
    path('procesarActualizacionCategoria',views.procesarActualizacionCategoria),
]
