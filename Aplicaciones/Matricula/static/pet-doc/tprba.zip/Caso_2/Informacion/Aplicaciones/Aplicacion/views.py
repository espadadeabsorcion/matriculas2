from django.http import JsonResponse
from django.views.decorators.http import require_GET
from django.shortcuts import render,redirect
from django.contrib import messages
from .models import Aplicacion
from .models import Categorias
from django.core.serializers import serialize
import json
# Create your views here.
# Model(BDD) - Template(GUI) - View(Logica de Negocio)
# Metodo para renderizar el listado de productos
#---------------------------------Aplicacion Views---------------------------------
def index(request):

    aplicaciones = Aplicacion.objects.all()
    categorias = Categorias.objects.all()
    contexto = {
        'aplicaciones': aplicaciones,
        'categorias': categorias
    }
    return render(request, 'index.html', contexto)

def nuevaAplicacion(request):
    categorias = Categorias.objects.all()
    return render(request, "nuevaAplicacion.html", {'categorias': categorias})

def guardarAplicacion(request):
    nom=request.POST['nombre']
    descripcion=request.POST['descripcion']
    categoria_id=request.POST['categoria']
    precio=request.POST['precio']
    stock=request.POST['stock']
    icono = request.FILES.get('icono')
    categoria = Categorias.objects.get(id=categoria_id)
    nuevaAplicacion=Aplicacion.objects.create(
        nombre=nom,
        descripcion=descripcion,
        categoria=categoria,
        precio=precio,
        stock=stock,
        icono=icono
             
    )
    messages.success(request,'Aplicacion registrada correctamente')
    return redirect('/')

def eliminarAplicacion(request,id):
    aplicacion=Aplicacion.objects.get(id=id)
    aplicacion.delete()
    messages.success(request,'Aplicacion eliminada correctamente')   
    return redirect('/')

def editarAplicacion(request,id):
    aplicacion=Aplicacion.objects.get(id=id)
    categorias = Categorias.objects.all()
    return render(request,"editarAplicacion.html",{'aplicacion':aplicacion, 'categorias':categorias})

def procesarActualizacionAplicacion(request):
    id = request.POST['id']
    nombre=request.POST['nombre']
    descripcion=request.POST['descripcion']
    categoria_id=request.POST['categoria']
    precio=request.POST['precio']
    stock=request.POST['stock']
    icono = request.FILES.get('icono')
    categoria = Categorias.objects.get(id=categoria_id)

    aplicacionEditar=Aplicacion.objects.get(id=id)
    aplicacionEditar.nombre=nombre
    aplicacionEditar.descripcion=descripcion
    aplicacionEditar.categoria=categoria
    aplicacionEditar.precio=precio
    aplicacionEditar.stock=stock
    aplicacionEditar.icono=icono
    aplicacionEditar.save()
    messages.success(request,'Aplicacion actualizada correctamente')
    return redirect('/')
#---------------------------------Categorias Views---------------------------------
def vistaCategorias(request):

    categorias = Categorias.objects.all()
    return render(request, 'vistaCategorias.html', {'categorias':categorias})

def nuevaCategoria(request):
    return render(request,"nuevaCategoria.html")

def guardarCategoria(request):
    nom=request.POST['nombre']
    descripcion=request.POST['descripcion']
    nuevaCategoria=Categorias.objects.create(
        nombre=nom,
        descripcion=descripcion
             
    )
    messages.success(request,'Categoria registrada correctamente')
    return redirect('/')

def eliminarCategoria(request,id):
    categoria=Categorias.objects.get(id=id)
    categoria.delete()
    messages.success(request,'Categoria eliminada correctamente')   
    return redirect('/')

def editarCategoria(request,id):
    categoria=Categorias.objects.get(id=id)
    return render(request,"editarCategoria.html",{'categoria':categoria})

def  procesarActualizacionCategoria(request):
    id = request.POST['id']
    nombre=request.POST['nombre']
    descripcion=request.POST['descripcion']

    categoriaEditar=Categorias.objects.get(id=id)
    categoriaEditar.nombre=nombre
    categoriaEditar.descripcion=descripcion
    categoriaEditar.save()
    messages.success(request,'Categoria actualizada correctamente')
    return redirect('/')